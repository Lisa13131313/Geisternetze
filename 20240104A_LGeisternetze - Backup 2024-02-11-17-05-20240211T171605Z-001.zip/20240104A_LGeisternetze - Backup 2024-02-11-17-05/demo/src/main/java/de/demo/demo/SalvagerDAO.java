package de.demo.demo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;

import java.util.List;

public class SalvagerDAO {
    // Deklaration EntityManagerFactory
    private EntityManagerFactory entityManagerFactory;

    // Deklaration EntityManager
    private EntityManager entityManager;

    public SalvagerDAO() {
        // Instanziierung EntityManagerFactory
        entityManagerFactory = EntityManagerFactoryProvider.getEntityManagerFactory();

        // Instanziierung EntityManager
        entityManager = entityManagerFactory.createEntityManager();
    }

    // Abruf aller in der DB gespeicherten Salvager
    public List<Salvager> findAllSalvagers() {
        Query query = entityManager.createQuery("SELECT salvager FROM Salvager salvager");
        List<Salvager> salvagers = query.getResultList();
        return salvagers;
    }

    // Speichern einer neuen BERGENDEN Person
    public void saveNewSalvagerBP(Salvager salvager) {
        // Speichern des neuen Salvagers als BERGENDE Person
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.persist(salvager);
        entityTransaction.commit();
    }

    // Speichern einer neuen MELDENDEN Person
    public void saveNewSalvagerMP(Salvager salvager) {
        // Speichern des neuen Salvagers
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.persist(salvager);
        entityTransaction.commit();
    }
}
