package de.demo.demo;

import jakarta.persistence.*;

import java.io.Serializable;
import java.util.Date;

@Entity
public class Net implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int nr;

    private double locationX;

    private double locationY;

    private int size;

    private String status;

    private boolean inSalvage;

    private int personS;

    @Temporal(TemporalType.DATE)
    private Date lastChangedStatus;

    public Net() {
    }

    public Net(int nr, double locationX, double locationY, int size, String status, boolean inSalvage, int personS, Date lastChangedStatus) {
        this.nr = nr;
        this.locationX = locationX;
        this.locationY = locationY;
        this.size = size;
        this.status = status;
        this.inSalvage = inSalvage;
        this.personS = personS;
        this.lastChangedStatus = new Date();
    }

    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public double getLocationX() {
        return locationX;
    }

    public void setLocationX(double locationX) {
        this.locationX = locationX;
    }

    public double getLocationY() {
        return locationY;
    }

    public void setLocationY(double locationY) {
        this.locationY = locationY;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean getInSalvage() {
        return inSalvage;
    }

    public void setInSalvage(boolean inSalvage) {
        this.inSalvage = inSalvage;
    }

    public int getPersonS() {
        return personS;
    }

    public void setPersonS(int personS) {
        this.personS = personS;
    }

    public Date getLastChangedStatus() {
        return lastChangedStatus;
    }

    public void setLastChangedStatus(Date lastChangedStatus) {
        this.lastChangedStatus = lastChangedStatus;
    }
}