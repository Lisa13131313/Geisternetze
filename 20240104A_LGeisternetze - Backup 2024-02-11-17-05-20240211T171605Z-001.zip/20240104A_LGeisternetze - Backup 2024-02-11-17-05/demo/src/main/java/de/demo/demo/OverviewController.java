package de.demo.demo;

import jakarta.annotation.PostConstruct;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.List;

@Named
@ViewScoped
public class OverviewController implements Serializable {
    // NetDAO
    private NetDAO netDAO;

    private List<Net> nets;

    public OverviewController() {
        netDAO = new NetDAO();
    }

    @PostConstruct
    public void init() {
        // Get the list of nets
        this.nets = getNetsByStatus();
    }

    // Alle Netze mit Status "gemeldet" aufsteigend nach ID sortiert aus der DB holen (DAO)
    public List<Net> getNetsByStatus()
    {
        List<Net> nets = netDAO.getNetsByStatus();
        this.nets = nets;
        return nets;
    }

    public List<Net> getNets() {
        return nets;
    }

    public void setNets(List<Net> nets) {
        this.nets = nets;
    }

    public String goBack() {
        return "verwaltung.xhtml";
    }
}
