package de.demo.demo;

import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

import java.io.Serializable;

@Named
@ViewScoped
public class RegistrationController implements Serializable {
    // SalvagerDAO
    private SalvagerDAO salvagerDAO;

    // Klassenvariable vom Typ Net zum Speichern eines neuen Netzes (anonym; Initialisierung mit null)
    private Salvager newSalvager = null;

    public RegistrationController() {
        salvagerDAO = new SalvagerDAO();
    }

    // Getter: Methode zur Rückgabe (bzw. auch zum Erstellen) eines (neuen) Salvagers (bei Bedarf)
    public Salvager getNewSalvager() {
        // Prüfung, ob ein Salvager-Objekt zur Verfügung steht oder neu erzeugt werden muss
        if (null == this.newSalvager) {
            this.newSalvager = new Salvager();
        }

        return this.newSalvager;
    }

    // Abbruch der Erfassung eines neuen Netzes
    public String cancelNewSalvager() {
        return "index.xhtml";
    }

    // Speichern einer neuen BERGENDEN Person (DAO)
    public String saveNewSalvager1() {
        // Person als BERGENDE Person markieren
        this.newSalvager.setIsreporter(true);

        // Speichern des neuen Salvagers
        salvagerDAO.saveNewSalvagerBP(this.newSalvager);

        // Rückkehr zur Übersichtsseite
        return "index.xhtml";
    }

    // Speichern einer neuen MELDENDEN Person (DAO)
    public String saveNewSalvager2() {
        // Person als MELDENDE Person markieren
        this.newSalvager.setIsreporter(false);

        // Speichern des neuen Salvagers
        salvagerDAO.saveNewSalvagerMP(this.newSalvager);

        // Rückkehr zur Übersichtsseite
        return "index.xhtml";
    }
}