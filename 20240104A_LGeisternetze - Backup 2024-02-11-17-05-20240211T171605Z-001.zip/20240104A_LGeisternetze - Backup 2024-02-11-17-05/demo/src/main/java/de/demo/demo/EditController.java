package de.demo.demo;

import jakarta.annotation.PostConstruct;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.util.Date;

@Named
@ViewScoped
public class EditController implements Serializable {
    // NetDAO
    private NetDAO netDAO;

    // Ausgewählter Index zur Bearbeitung
    private int selectedNetNr;

    // Klassenvariable vom Typ Net zum Speichern eines zur Bearbeitung ausgewählten Netzes (Initialisierung mit null)
    private Net editNet = null;

    // Klassenvariable für Start-Datum zur Erfassung eines neuen Netzes
    private Date currentDate;

    public EditController() {
        netDAO = new NetDAO();
    }

    public int getSelectedNetNr() {
        return selectedNetNr;
    }

    public void setSelectedNetNr(int selectedNetNr) {
        this.selectedNetNr = selectedNetNr;
    }

    // Setter für selectedNetNr in der Session
    public void setSelectedNetNrInSession(int selectedNetNr) {
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("selectedNetNr", selectedNetNr);
    }

    // Getter für selectedNetNr in der Session
    public int getSelectedNetNrFromSession() {
        return (int) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("selectedNetNr");
    }

    // Getter: Methode zur Rückgabe (bzw. auch zum Erstellen) eines (neuen) Netzes (bei Bedarf)
    public Net getEditNet() {
        // Prüfung, ob ein Netz-Objekt zur Verfügung steht oder neu erzeugt werden muss
        if (null == this.editNet) {
            this.editNet = new Net();
        }

        return this.editNet;
    }

    public Date getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(Date currentDate) {
        this.currentDate = currentDate;
    }

    @PostConstruct
    public void init() {
        setCurrentDate(new Date());

        // Ausgewähltes Netz (Nr) aus Session ermitteln
        this.selectedNetNr = getSelectedNetNrFromSession();

        // Netz aus DB abrufen
        this.editNet = getNetById(this.selectedNetNr);
    }

    // Ausgewähltes Netz über seine ID aus der DB holen (DAO)
    public Net getNetById(int nr) {
        this.editNet = netDAO.getNetById(nr);
        return this.editNet;
    }

    // Abbruch der Erfassung eines neuen Netzes
    public String cancelEditNet() {
        return "verwaltung.xhtml";
    }

    // Speichern eines editierten Netzes (DAO)
    public String saveEditedNet() {
        // Datum manuell auf aktuellen Tag setzen
        this.editNet.setLastChangedStatus(this.currentDate);

        netDAO.saveEditedNetDB(this.editNet);

        // Rückkehr zur Übersichtsseite
        return "verwaltung.xhtml";
    }
}
