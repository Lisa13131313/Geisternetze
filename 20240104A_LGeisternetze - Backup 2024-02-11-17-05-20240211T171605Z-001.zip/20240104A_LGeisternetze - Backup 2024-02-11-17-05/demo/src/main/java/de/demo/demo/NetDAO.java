package de.demo.demo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Query;

import java.util.Date;
import java.util.List;

public class NetDAO {
    // Deklaration EntityManagerFactory
    private EntityManagerFactory entityManagerFactory;

    // Deklaration EntityManager
    private EntityManager entityManager;

    public NetDAO() {
        // Instanziierung EntityManagerFactory
        entityManagerFactory = EntityManagerFactoryProvider.getEntityManagerFactory();

        // Instanziierung EntityManager
        entityManager = entityManagerFactory.createEntityManager();
    }

    // Abruf aller in der DB gespeicherten Netze
    public List<Net> findAll() {
        // Transaktion starten
        entityManager.getTransaction().begin();

        Query query = entityManager.createQuery("SELECT net FROM Net net");
        List<Net> nets = query.getResultList();

        // Änderungen an der Datenbank sofort zurückgeben
        entityManager.flush();

        // Transaktion abschließen
        entityManager.getTransaction().commit();

        // Prüfung, ob Liste mit Net-Objekten leer ist (hinzufügen eines Standard-Netzes wg. Fehler)
        if (nets.isEmpty() || nets == null) {
            nets.add(new Net(999, 22.222, 33.333, 20, "in_salvage", true, 33, new Date()));
        }

        return nets;
    }

    // Ausgewähltes Netz über seine ID aus der DB holen
    public Net getNetById(int nr) {
        Query query = entityManager.createQuery("SELECT net FROM Net net WHERE net.nr = :nr");
        query.setParameter("nr", nr);

        Net net = (Net) query.getSingleResult();

        if (net == null) {
            throw new NullPointerException("Netz mit der ID " + nr + " nicht gefunden.");
        }

        return net;
    }

    // Alle Netze mit Status "gemeldet" aufsteigend nach ID sortiert aus der DB holen
    public List<Net> getNetsByStatus() {
        Query query = entityManager.createQuery("SELECT net FROM Net net WHERE net.status = 'Gemeldet' ORDER BY net.nr ASC");
        List<Net> nets = query.getResultList();
        entityManager.close();
        return nets;
    }

    // Speichern eines neuen Netzes in der DB
    public void saveDB(Net net) {
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.merge(net);
        entityTransaction.commit();
    }

    // Speichern eines editierten Netzes
    public void saveEditedNetDB(Net editedNet) {
        EntityTransaction entityTransaction = entityManager.getTransaction();
        entityTransaction.begin();
        entityManager.merge(editedNet);
        entityTransaction.commit();
    }
}
