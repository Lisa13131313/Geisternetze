package de.demo.demo;

import java.io.Serializable;
import java.util.List;

import jakarta.enterprise.context.SessionScoped;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.component.UIComponent;
import jakarta.faces.component.UIInput;
import jakarta.faces.context.FacesContext;
import jakarta.faces.event.AbortProcessingException;
import jakarta.faces.event.ComponentSystemEvent;
import jakarta.faces.validator.ValidatorException;
import jakarta.inject.Named;
import jakarta.inject.Inject;

@Named
@SessionScoped
public class LoginController implements Serializable {
    // SalvagerDAO
    private SalvagerDAO salvagerDAO;

    // Liste mit Salvagers zum Login
    private List<Salvager> salvagers;

    // Salvager-Objekt für validateLogin()
    @Inject
    private Salvager salvager;

    public LoginController() {
        salvagerDAO = new SalvagerDAO();
    }

    // GETTER für Salvager-Objekt für validateLogin()
    public Salvager getSalvager() {
        return this.salvager;
    }

    // SETTER für Salvager-Objekt für validateLogin()
    public void setSalvager(Salvager salvager) {
        this.salvager = salvager;
    }

    // DB-Abruf aller gespeicherten Salvagers und Speicherung in Klassenvariable (salvagers)
    public List<Salvager> getSalvagers() {
        this.salvagers = salvagerDAO.findAllSalvagers();
        return salvagers;
    }

    // Login-Methode
    public String login() {
        // Liste mit registrierten Meldern/Bergern aus DB abrufen (auch wg. Registrierung)
        getSalvagers();

        for (Salvager s : this.salvagers) {
            if (s.equals(this.salvager)) {
                // Attribute des akzeptierten Nutzers (aus der DB) im Salvager-Objekt speichern
                // zur weiteren Nutzung in der Session
                salvager.setId(s.getId());
                salvager.setLastname(s.getLastname());
                salvager.setForename(s.getForename());
                salvager.setPhone(s.getPhone());
                salvager.setUsername(s.getUsername());
                salvager.setIsreporter(s.getIsreporter());

                return "verwaltung.xhtml";
            }
        }
        return "index.xhtml";
    }

    // Validierung Username und Vorbereitung Validierung Login
    public void postValidateUsername(ComponentSystemEvent ev) throws AbortProcessingException {
        UIInput temp = (UIInput) ev.getComponent();
        salvager.setUsername((String) temp.getValue());
    }

    // Validierung Login
    public void validateLogin(FacesContext context, UIComponent component, Object value) throws ValidatorException {
        // Prüfung, ob salvagers bereits die Liste mit gespeicherten Salvagers enthält, sonst Abruf aus DB
        if (this.salvagers == null) {
            getSalvagers();
        }

        // FOREACH: Prüfung jedes einzelnen Salvager-Objekts aus der DB mit den eingegebenen Zugangsdaten
        for (Salvager s : this.salvagers) {
            Salvager temp = new Salvager(salvager.getUsername(), (String) value);
            if (s.equals(temp))
                return;
        }

        throw new ValidatorException(new FacesMessage("Benutzername und/oder Passwort sind falsch."));
    }

    // Weiterleitung zur anonymen Meldung eines Netzes
    public String showAnoErfassungForm() {
        return "erfassunganonym.xhtml";
    }

    // Weiterleitung zur Registrierung als BERGENDE Person
    public String showRegistrationForm1() {
        return "registrierung1.xhtml";
    }

    // Weiterleitung zur Registrierung als MELDENDE Person
    public String showRegistrationForm2() {
        return "registrierung2.xhtml";
    }

    public String logout() {
        // Salvager-Objekt zerstören
        setSalvager(new Salvager());

        // Rückkehr zur Startseite
        return "index.xhtml";
    }
}