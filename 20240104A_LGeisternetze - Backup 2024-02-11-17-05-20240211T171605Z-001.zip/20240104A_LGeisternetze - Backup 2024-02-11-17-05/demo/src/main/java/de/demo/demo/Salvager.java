package de.demo.demo;

import jakarta.enterprise.context.SessionScoped;
import jakarta.inject.Named;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import java.io.Serializable;

@Entity
@Named
@SessionScoped
public class Salvager implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String lastname;

    private String forename;

    private String phone;

    private String username;

    private String password;

    private boolean isreporter;

    public Salvager() {
    }

    public Salvager(String username, String password) {
        this.setUsername(username);
        this.setPassword(password);
    }

    public Salvager(int id, String lastname, String forename, String phone, String username, String password, boolean isreporter) {
        this.id = id;
        this.lastname = lastname;
        this.forename = forename;
        this.phone = phone;
        this.username = username;
        this.password = password;
        this.isreporter = isreporter;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public String getForename() {
        return forename;
    }

    public void setForename(String forename) {
        this.forename = forename;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean getIsreporter() {
        return isreporter;
    }

    public void setIsreporter(boolean isreporter) {
        this.isreporter = isreporter;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof Salvager) {
            Salvager s = (Salvager) obj;
            if (s.getUsername().equals(this.username) && s.getPassword().equals(this.password))
                return true;
        }
        return false;
    }
}