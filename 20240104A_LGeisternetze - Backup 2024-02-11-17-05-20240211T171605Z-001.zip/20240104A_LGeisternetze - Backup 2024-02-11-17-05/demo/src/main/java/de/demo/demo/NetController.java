package de.demo.demo;

import java.io.Serializable;

import jakarta.annotation.PostConstruct;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Named
@ViewScoped
public class NetController implements Serializable {
    // NetDAO
    private NetDAO netDAO;

    // Liste mit Netzen (Initialisierung mit leerer Liste)
    private List<Net> nets;

    // Klassenvariable Index zur Navigation durch die gespeicherten Netze
    private int index = 0;

    // Ausgewähltes Net (Nr in DB) zur Bearbeitung
    private int selectedNetNr;

    // Klassenvariable vom Typ Net zum Speichern eines neuen Netzes (Initialisierung mit null für Abgleich)
    private Net newNet = null;

    // Klassenvariable für Start-Datum zur Erfassung eines neuen Netzes
    private Date currentDate;

    public NetController() {
        this.nets = new ArrayList<>();
        netDAO = new NetDAO();
    }

    public void setNets(List<Net> nets) {
        this.nets = nets;
    }

    public List<Net> getNets()
    {
        this.nets = netDAO.findAll();
        return this.nets;
    }

    public Date getCurrentDate() {
        return currentDate;
    }

    public void setCurrentDate(Date currentDate) {
        this.currentDate = currentDate;
    }

    @PostConstruct
    public void init() {
        setCurrentDate(new Date());
    }

    // Methode: Getter für ein bestimmtes Netz
    public Net getNet() {
        return nets.get(index);
    }

    // Methode: Blätterfunktion
    public void vor() {
        if (index < getMaxIndex()) {
            index++;
        }
    }

    // Methode: Blätterfunktion
    public void zurueck() {
        if (index > 0) {
            index--;
        }
    }

    // Methode zum Ermitteln des aktuellen Netz-Indexes
    public int getIndex() {
        return index;
    }

    // Methode zum Ermitteln der Anzahl an Netze
    public int getMaxIndex() {
        return getNets().size() - 1;
    }

    // Methode zum Hinzufügen neuer Netze: Weiterleitung auf Erfassungs-Seite
    public String add() {
        // Abrufen/Erzeugen einer Netz-Instanz
        getNewNet();

        return "erfassung.xhtml";
    }

    // Getter: Methode zur Rückgabe (bzw. auch zum Erstellen) eines (neuen) Netzes (bei Bedarf)
    public Net getNewNet() {
        // Prüfung, ob ein Netz-Objekt zur Verfügung steht oder neu erzeugt werden muss
        if (null == this.newNet) {
            this.newNet = new Net();
        }

        return this.newNet;
    }

    // Speichern eines neuen Netzes in der DB (über DAO)
    public void saveNewNet(Net newNet) {
        netDAO.saveDB(newNet);
    }

    // Getter für selectedNetNr
    public int getSelectedNetNr() {
        // selectedNetNr aus Session abrufen
        return getSelectedNetNrFromSession();
    }

    // Setter für selectedNetNr
    public void setSelectedNetNr(int selectedNetNr) {
        this.selectedNetNr = selectedNetNr;
    }

    // Setter für selectedNetNr in der Session
    public void setSelectedNetNrInSession(int selectedNetNr) {
        FacesContext.getCurrentInstance().getExternalContext().getSessionMap().put("selectedNetNr", selectedNetNr);
    }

    // Getter für selectedNetNr in der Session
    public int getSelectedNetNrFromSession() {
        return (int) FacesContext.getCurrentInstance().getExternalContext().getSessionMap().get("selectedNetNr");
    }

    // Speicherung der selectedNetNr zum Ändern eines Netzes in der Session und Weiterleitung zur Bearbeitungsseite
    // für bergende Personen
    public String editNet1() {
        // selectedNetNr in Session speichern (für Zugriff durch EditController
        setSelectedNetNrInSession(this.selectedNetNr);

        // Weiterleitung zur Bearbeitungsseite
        return "aenderung1.xhtml";
    }

    // Speicherung der selectedNetNr zum Ändern eines Netzes :: als verschollen erklären
    public String editNet2() {
        // selectedNetNr in Session speichern (für Zugriff durch EditController
        setSelectedNetNrInSession(this.selectedNetNr);

        // Weiterleitung zur Bearbeitungsseite
        return "aenderung2.xhtml";
    }

    // Abbruch der Erfassung eines neuen Netzes
    public String cancelNewNet() {
        return "verwaltung.xhtml";
    }

    // Abbruch der ANONYMEN Erfassung eines neuen Netzes
    public String cancelNewAnoNet() {
        return "index.xhtml";
    }

    // Methode zum Speichern eines neu erfassten Netzes
    public String saveNewNet() {
        // MELDENDE Person kann Netz melden
        newNet.setInSalvage(false);
        newNet.setLastChangedStatus(this.currentDate); // Datum manuell auf aktuellen Tag setzen

        // Speichern des neuen Netzes
        netDAO.saveDB(newNet);

        // Klassenvariable nach dem Speichern zurücksetzen
        this.newNet = null;

        // Rückkehr zur Übersichtsseite
        return "verwaltung.xhtml";
    }

    // Methode zum Speichern eines neu erfassten ANONYMEN Netzes
    public String saveNewAnoNet() {
        // ANONYME Person kann Netz melden
        newNet.setInSalvage(false);
        newNet.setLastChangedStatus(this.currentDate); // Datum manuell auf aktuellen Tag setzen

        // Speichern des neuen Netzes
        //Allnets.getInstance().saveNewNet(newNet);
        netDAO.saveDB(newNet);

        // Klassenvariable nach dem Speichern zurücksetzen
        this.newNet = null;

        // Rückkehr zur Übersichtsseite
        return "index.xhtml";
    }

    public String ovNets() {
        OverviewController overviewController = new OverviewController();
        overviewController.getNetsByStatus();

        return "overview.xhtml";
    }
}