package de.demo.demo;

import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class EntityManagerFactoryProvider
{
    private final static EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("geisternetze");

    public static EntityManagerFactory getEntityManagerFactory()
    {
        return entityManagerFactory;
    }
}